const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const { spawn, execFile } = require('node:child_process');
const frontend = path.join(__dirname, 'frontend');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
let server;

function install() {
  console.log('Installing locked dependencies. Internet access is required for the first launch.');
  const windows = process.platform === 'win32';
  const command = windows ? (process.env.ComSpec || 'cmd.exe') : 'npm';
  const args = windows ? ['/d', '/s', '/c', 'npm ci --include=dev'] : ['ci', '--include=dev'];
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: frontend, stdio: 'inherit' });
    child.once('error', reject);
    child.once('exit', code => code === 0 ? resolve() : reject(new Error(`npm ci failed (${code}). Check your Internet connection and npm output.`)));
  });
}
async function freePort() {
  for (let port = 3000; port <= 3010; port++) {
    const available = await new Promise(resolve => {
      const probe = net.createServer();
      probe.once('error', () => resolve(false));
      probe.listen(port, '0.0.0.0', () => probe.close(() => resolve(true)));
    });
    if (available) return port;
  }
  throw new Error('Ports 3000-3010 are busy. Close an unused local server and try again.');
}
function openBrowser(url) {
  if (process.env.WELD_NO_OPEN === '1' || process.argv.includes('--no-open')) return;
  if (process.platform === 'win32') {
    execFile(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `start "" "${url}"`], error => {
      if (error) console.log(`Please open ${url} in your browser.`);
    });
  } else {
    execFile(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], error => {
      if (error) console.log(`Please open ${url} in your browser.`);
    });
  }
}
async function main() {
  if (Number(process.versions.node.split('.')[0]) < 24) throw new Error('Please install Node.js 24 LTS or newer: https://nodejs.org/');
  if (!fs.existsSync(path.join(frontend, 'package-lock.json'))) throw new Error('Extract the complete ZIP first. The frontend folder is missing.');
  const installed = ['next', 'react', 'three', 'typescript'].every(name => fs.existsSync(path.join(frontend, 'node_modules', name, 'package.json')));
  if (!installed) await install();
  const port = await freePort();
  const url = `http://localhost:${port}`;
  const next = require.resolve('next/dist/bin/next', { paths: [frontend] });
  console.log(`Starting WELD VISION on ${url}`);
  server = spawn(process.execPath, [next, 'dev', '-H', '0.0.0.0', '-p', String(port)], {
    cwd: frontend, stdio: 'inherit', env: { ...process.env, NEXT_PUBLIC_DATA_MODE: process.env.NEXT_PUBLIC_DATA_MODE || 'demo' },
  });
  let ended = false;
  const exit = new Promise((resolve, reject) => {
    server.once('error', reject);
    server.once('exit', code => { ended = true; resolve(code || 0); });
  });
  let ready = false;
  const deadline = Date.now() + 90000;
  while (!ended && Date.now() < deadline) {
    try {
      const response = await fetch(`${url}/`, { signal: AbortSignal.timeout(3000) });
      if (response.ok) { ready = true; break; }
    } catch { /* Wait until Next.js has compiled the first page. */ }
    await delay(500);
  }
  if (!ready) {
    server.kill();
    throw new Error('The web server did not become ready. Check the startup output above.');
  }
  console.log(`\nREADY: ${url}\nBrowser demo mode. No camera or robot controller is required.\nKeep this window open. Press Ctrl+C to stop.\n`);
  openBrowser(url);
  process.exitCode = await exit;
}
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { if (server) server.kill(signal); else process.exit(0); });
main().catch(error => { console.error(`\n${error.message}`); if (server) server.kill(); process.exitCode = 1; });
