import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "焊缝识别系统 · 机器人视觉工作台",
  description: "焊接机器人视觉智能系统 · 离线交互演示",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
