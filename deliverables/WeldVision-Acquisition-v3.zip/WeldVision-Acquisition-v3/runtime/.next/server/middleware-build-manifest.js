globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/VffYbWnliJVC8-h2dcpdq/_buildManifest.js",
    "static/VffYbWnliJVC8-h2dcpdq/_ssgManifest.js",
    "static/VffYbWnliJVC8-h2dcpdq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/19wg2q9r2_sev.js",
    "static/chunks/1f3_j0-7srs8o.js",
    "static/chunks/3wbm-994r45kr.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/19wg2q9r2_sev.js",
        "static/chunks/1f3_j0-7srs8o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/19wg2q9r2_sev.js",
        "static/chunks/1f3_j0-7srs8o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/19wg2q9r2_sev.js",
        "static/chunks/1f3_j0-7srs8o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
